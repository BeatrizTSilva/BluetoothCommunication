# eChook Companion App
The app can be downloaded from the [Google Play Store](https://play.google.com/store/apps/details?id=com.ben.drivenbluetooth). This repository only stores the code.
